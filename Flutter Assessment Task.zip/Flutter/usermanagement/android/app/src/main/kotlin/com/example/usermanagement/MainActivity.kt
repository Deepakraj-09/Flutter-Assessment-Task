package com.example.usermanagement

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
